﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectorLib
{
    public class FunctionInsp
    {
        string name = "Автоинспекция г. Чита";
        string name2 = "Васильев Василий Иванович";
        string name3 = "Иванов И.И.;Зиронов Т.А.; Миронов А.В.;Васильев В.И.; ";
        //string name4 = "A12_75";
        //string name5=""


        public string GetСarInspection()
        {
            return name;
        }
    
        public string GetInspector()
        {
            return name2;
        }

        public string GetWorker()
        {
            return name3;
        }

     //   public string GenerateNumber(number, symbol, code)
       // {
       //     return name4;
      //  }

       // public string AddWorker()
      //  {
      //      return name5;
      //  }
        
    }
}
